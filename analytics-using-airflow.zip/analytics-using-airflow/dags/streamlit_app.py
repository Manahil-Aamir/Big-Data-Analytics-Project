import streamlit as st
import redis
import json
import pandas as pd
import matplotlib 
import matplotlib.pyplot as plt

# Connect to Redis
redis_host = 'redis'  # Update this if Redis runs on a different host
redis_port = 6379  # Default Redis port
redis_client = redis.StrictRedis(host=redis_host, port=redis_port, decode_responses=True)

# Streamlit dashboard
st.title("Customer Data Analysis Dashboard")

try:
    # Fetch analyzed data from Redis
    analyzed_data_json = redis_client.get('analyzed_data')
    
    if analyzed_data_json:
        analyzed_data = json.loads(analyzed_data_json)
        
        # Display analyzed data
        st.subheader("Analysis Results")
        st.write("**Average Age of Customers:**")
        st.metric(label="Average Age", value=f"{analyzed_data.get('avg_age', 'N/A'):.2f}")
        
        # Visualize age groups (ensure the data is saved in Redis in the required format)
        if 'age_distribution' in analyzed_data:
            # Create a DataFrame for visualization
            age_distribution = pd.DataFrame(analyzed_data['age_distribution'], columns=['age_range', 'count'])
            
            # Bar chart for age distribution
            st.subheader("Customer Age Distribution")
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.bar(age_distribution['age_range'], age_distribution['count'], color='skyblue')
            ax.set_title('Age Distribution of Customers', fontsize=16)
            ax.set_xlabel('Age Range', fontsize=12)
            ax.set_ylabel('Count', fontsize=12)
            plt.xticks(rotation=45)
            st.pyplot(fig)
        else:
            st.warning("Age distribution data is not available in Redis.")
    else:
        st.warning("No data found in Redis. Please ensure the data pipeline ran successfully.")
except Exception as e:
    st.error(f"Error connecting to Redis or fetching data: {e}")

# Footer
st.sidebar.title("Data Pipeline Status")
st.sidebar.info("Ensure the Airflow DAG and Spark tasks have run before viewing the dashboard.")
