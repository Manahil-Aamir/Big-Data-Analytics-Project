from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime
import pandas as pd
import redis
import json
import os

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2024, 12, 30),
    'retries': 1,
}

# Function to load CSV to PostgreSQL
def upload_csv_to_postgres(csv_file_path, table_name, **kwargs):
    # Load the CSV into a pandas DataFrame
    df = pd.read_csv(csv_file_path)
    
    # Create a connection to PostgreSQL
    pg_hook = PostgresHook(postgres_conn_id='postgres_default')  # Assuming connection is set in Airflow
    conn = pg_hook.get_conn()
    cursor = conn.cursor()

    # Create table if it doesn't exist
    create_table_query = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR,
        first_name VARCHAR,
        last_name VARCHAR,
        username VARCHAR,
        email VARCHAR,
        gender VARCHAR,
        birthdate DATE,
        device_type VARCHAR,
        device_id VARCHAR,
        device_version VARCHAR,
        home_location_lat DECIMAL,
        home_location_long DECIMAL,
        home_location VARCHAR,
        home_country VARCHAR,
        first_join_date DATE
    );
    """
    cursor.execute(create_table_query)
    
    # Insert data into PostgreSQL
    for index, row in df.iterrows():
        insert_query = f"""
        INSERT INTO {table_name} (
            customer_id, first_name, last_name, username, email, gender, birthdate,
            device_type, device_id, device_version, home_location_lat, home_location_long,
            home_location, home_country, first_join_date
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (
            row['customer_id'], row['first_name'], row['last_name'], row['username'], row['email'], 
            row['gender'], row['birthdate'], row['device_type'], row['device_id'], row['device_version'], 
            row['home_location_lat'], row['home_location_long'], row['home_location'], 
            row['home_country'], row['first_join_date']
        ))
    
    conn.commit()
    cursor.close()

# Function to cache results in Redis
#def cache_results_in_redis(**kwargs):
    # Connect to Redis
    #r = redis.Redis(host='redis', port=6379, db=0)

    # Example analyzed data to cache
    #analyzed_data = kwargs['analyzed_data']  # This would come from the output of your analysis

    # Store the data in Redis
    #r.set('analyzed_data', json.dumps(analyzed_data))

with DAG(
    dag_id='data_pipeline',
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False,
) as dag:

    start = DummyOperator(task_id='start')

    # Step 1: Upload CSV to PostgreSQL (for customer.csv in this example)
    upload_to_postgres_customer = PythonOperator(
        task_id='upload_to_postgres_customer',
        python_callable=upload_csv_to_postgres,
        op_kwargs={'csv_file_path': '/opt/airflow/data/customer.csv', 'table_name': 'customer_data'}
    )

    # Step 2: Upload CSV to PostgreSQL (for transactions.csv in this example)
    #upload_to_postgres_transactions = PythonOperator(
    #    task_id='upload_to_postgres_transactions',
    #    python_callable=upload_csv_to_postgres,
    #    op_kwargs={'csv_file_path': '/opt/airflow/data/transactions.csv', 'table_name': 'transactions'}
    #)

    # Step 3: Analyze data with Spark
    analyze_with_spark = BashOperator(
        task_id='analyze_with_spark',
        bash_command="export PATH=$SPARK_HOME/bin:$PATH && spark-submit --master local /opt/airflow/dags/analyze.py",
    )

    # Step 4: Cache the analysis results in Redis
    #cache_results = PythonOperator(
        #task_id='cache_results',
        #python_callable=cache_results_in_redis,
        #op_kwargs={'analyzed_data': {'result': 'some_analysis_output'}}  # Placeholder for actual result
    #)

    # Step 5: Display result on Streamlit dashboard (assuming Streamlit is set up separately)
    # Assuming Streamlit is running in a separate container and is watching the Redis cache.
    display_in_streamlit = BashOperator(
        task_id='display_in_streamlit',
        bash_command="export PATH=$PATH:/path/to/streamlit && streamlit run /opt/airflow/dags/streamlit_app.py",
    )

    end = DummyOperator(task_id='end')

    # Task dependencies: 
    start >> upload_to_postgres_customer >> analyze_with_spark >> display_in_streamlit >> end
