from pyspark.sql import SparkSession
import pandas as pd
import redis
import json

# Initialize Spark session
spark = SparkSession.builder \
    .appName("Data Analysis with Spark") \
    .getOrCreate()

# Load your CSV files into Spark DataFrame (using the same customer.csv example)
csv_file_path = '/opt/airflow/data/customer.csv'
df_spark = spark.read.csv(csv_file_path, header=True, inferSchema=True)

# Create a temporary view for Spark SQL queries
df_spark.createOrReplaceTempView("customer_data")

# Example: Data analysis step (you can modify this as per your analysis needs)
# Let's calculate the average age of customers as an example analysis.
# Example: Calculate the average age of customers
average_age_result = spark.sql("""
    SELECT AVG(DATEDIFF(current_date(), birthdate) / 365) AS avg_age
    FROM customer_data
""")

# Collect the result as a Python dictionary
analyzed_data = average_age_result.collect()[0].asDict()

# Calculate age distribution
age_distribution = spark.sql("""
    SELECT 
        CASE 
            WHEN (DATEDIFF(current_date(), birthdate) / 365) BETWEEN 0 AND 17 THEN '0-17'
            WHEN (DATEDIFF(current_date(), birthdate) / 365) BETWEEN 18 AND 25 THEN '18-25'
            WHEN (DATEDIFF(current_date(), birthdate) / 365) BETWEEN 26 AND 35 THEN '26-35'
            WHEN (DATEDIFF(current_date(), birthdate) / 365) BETWEEN 36 AND 45 THEN '36-45'
            ELSE '46+'
        END AS age_range,
        COUNT(*) AS count
    FROM customer_data
    GROUP BY age_range
""").collect()

# Format age distribution for Redis
age_distribution_formatted = [{'age_range': row['age_range'], 'count': row['count']} for row in age_distribution]
analyzed_data['age_distribution'] = age_distribution_formatted

# Connect to Redis
redis_client = redis.StrictRedis(host='redis', port=6379, decode_responses=True)

# Save the analyzed data in Redis
redis_client.set('analyzed_data', json.dumps(analyzed_data))

# Optionally, print the result for debugging
print(f"Analyzed Data: {json.dumps(analyzed_data, indent=4)}")

# Stop the Spark session
spark.stop()