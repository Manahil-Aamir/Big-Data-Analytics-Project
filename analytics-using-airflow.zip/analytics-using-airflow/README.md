# Customer Dashboard Using Airflow

This project is designed to create a customer dashboard by orchestrating workflows using Apache Airflow. The architecture includes the ingestion, transformation, and visualization of data using Docker containers.

---

## Architecture Flow

The workflow follows this sequence:

1. **[Start]**  
   Initiates the workflow process.

2. **[Load CSV to PostgreSQL]**  
   Raw CSV data is ingested into a PostgreSQL database for structured storage and efficient querying.

3. **[Analyze Data with Spark]**  
   Apache Spark processes and analyzes the data, applying transformations and generating insights.

4. **[Cache Results in Redis]** *(Optional)*  
   Intermediate results can be cached in Redis to reduce query latency for repetitive operations.

5. **[Streamlit Dashboard]**  
   A Streamlit application fetches data from the PostgreSQL/Redis storage and visualizes it on an interactive dashboard.

6. **[End]**  
   Marks the completion of the workflow.

---

## Folder Structure

- **dags/**: Contains Airflow DAGs (Directed Acyclic Graphs) to orchestrate workflows.
- **data/**: Stores raw and processed data.
- **logs/**: Airflow logs for debugging and tracking workflow runs.
- **pg_data/**: Persistent storage for PostgreSQL database.
- **plugins/**: Custom plugins for extending Airflow functionality.
- **streamlit_app/**: Streamlit application for data visualization.
- **docker-compose.yml**: Docker Compose file to set up and run the environment.
- **Dockerfile**: Custom Docker image for the project.

---

## Prerequisites

Before running the project, ensure the following tools are installed on your system:

1. **Docker**: [Download and Install Docker](https://www.docker.com/).
2. **Docker Compose**: Comes pre-installed with Docker Desktop.
3. **Apache Airflow**: The architecture will set this up in a Dockerized environment.

---

## Setup Instructions

Follow these steps to set up and run the project:

1. **Clone the repository**:
   
bash
   git clone https://github.com/Manahil-Aamir/Big-Data-Analytics-Project.git
   cd Big-Data-Analytics-Project/analysis-using-airflow


2. **Build and Start the Dockerized Environment**:
   
bash
   docker-compose up --build


3. **Access Airflow Web Server**:
   - Open your browser and navigate to: [http://localhost:8080](http://localhost:8080)  
   - Default credentials:  
     - **Username**: admin  
     - **Password**: admin  

4. **Run the Streamlit Application**:
   
bash
   cd streamlit_app
   streamlit run app.py


5. **Access the Streamlit Dashboard**:
   - Open your browser and navigate to: [http://localhost:8501](http://localhost:8501).

---

## Usage

### Trigger DAGs
- Log into the Airflow Web Server and manually trigger DAGs or schedule them as required.

### Monitor Logs
- Logs for Airflow DAGs can be found in the **logs/** folder.

### Visualize Data
- Use the Streamlit dashboard to visualize processed data interactively.

---

## Files in This Folder

1. **docker-compose.yml**: Defines services for Airflow, PostgreSQL, and other components.
2. **Dockerfile**: Customizes the Docker image for the Airflow environment.

